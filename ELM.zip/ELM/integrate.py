
#from math import fabs
#from pickle import TRUE
#from re import T
#import torch
#import torch.nn as nn
#import torch.nn.functional as F
#import numpy as np
#import torch
#import torch.nn as nn
#import torch.nn.functional as F
#import numpy as np
#import torch.fft
#from torch.cuda.amp import autocast
##from callback.revin import RevIN



#from torch import nn
#import torch


#class Model(nn.Module):
#    """
#    Just one Linear layer
#    """
#    def __init__(self, pred_len, seq_len, enc_in, batch_size2):
#        super(Model, self).__init__()
#        self.seq_len = seq_len
#        self.pred_len = pred_len
#        self.batch_size2=batch_size2

#        # Use this line if you want to visualize the weights
#        # self.Linear.weight = nn.Parameter((1/self.seq_len)*torch.ones([self.pred_len,self.seq_len]))
#        self.channels = enc_in
#        self.batch_norm = nn.BatchNorm1d(self.channels)
        
        
#        self.individual =False
#        if self.individual:
#            self.Linear = nn.ModuleList()
#            for i in range(self.channels):
#                self.Linear.append(nn.Linear(self.seq_len,self.pred_len))
#        else:
#            self.Linear = nn.Linear(self.seq_len, self.pred_len)
                               
            
#    def forward(self, x):
        

#            if self.individual:
#                output = torch.zeros([x.size(0),self.pred_len,x.size(2)],dtype=x.dtype).to(x.device)
#                for i in range(self.channels):
#                    output[:,:,i] = self.Linear[i](x[:,:,i])
#                x = output
#            else:
#                x=self.Linear(x.permute(0, 2, 1)).permute(0, 2, 1)
#                #x=F.gelu(self.Linear(x.permute(0, 2, 1)).permute(0, 2, 1))
#            # print(x.shape)
            
#            x=x.permute(0,2,1)
#            x=self.batch_norm(x)
            
#            x=x.permute(0,2,1)
#            return x



#class Model2(nn.Module):
#    """
#    Normalization-Linear
#    """
#    def __init__(self, pred_len,seq_len,enc_in):
#        super(Model2, self).__init__()
#        self.seq_len = seq_len
#        self.pred_len = pred_len
        
#        # Use this line if you want to visualize the weights
#        # self.Linear.weight = nn.Parameter((1/self.seq_len)*torch.ones([self.pred_len,self.seq_len]))
#        self.channels = enc_in
#        self.batch_norm = nn.BatchNorm1d(self.channels)
        
#        self.individual=False
#        if self.individual:
#            self.Linear = nn.ModuleList()
#            for i in range(self.channels):
#                #self.batch_norm(self.Linear.append(nn.Linear(self.seq_len,self.pred_len)))
#                self.Linear.append(nn.Linear(self.seq_len,self.pred_len))
#        else:
#            self.Linear = nn.Linear(self.seq_len, self.pred_len)
        
#    def forward(self, x):
        

#            # x: [Batch, Input length, Channel]
#            seq_last = x[:,-1:,:].detach()

#            x = x - seq_last
#            if self.individual:
#                output = torch.zeros([x.size(0),self.pred_len,x.size(2)],dtype=x.dtype).to(x.device)
#                for i in range(self.channels):
#                    output[:,:,i] = self.Linear[i](x[:,:,i])
#                x = output
#            else:
#                x = self.Linear(x.permute(0,2,1)).permute(0,2,1)
#            x = x + seq_last

            
#            x=x.permute(0,2,1)
#            x=self.batch_norm(x)
            
#            x =x.permute(0,2,1)
        
#            return x # [Batch, Output length, Channel]



#class IntegratedModel(nn.Module):
#    def __init__(self, pred_len, seq_len, enc_in, batch_size2):
#        super(IntegratedModel, self).__init__()
#        self.pred_len = pred_len
#        self.seq_len = seq_len
#        self.channels = enc_in
#        self.batch_norm = nn.BatchNorm1d(self.channels)
        
#        self.model2 = Model2(pred_len, seq_len, enc_in)
#        self.model = Model(pred_len, seq_len, enc_in, batch_size2)

#    def forward(self, x):
#        # Get outputs from both models
#        output_model2 = self.model2(x)
#        output_model = self.model(x)
       
#        # Average the outputs instead of concatenating
#        #x =(output_model2 + output_model) /2
      
#        x = F.gelu((output_model2 + output_model) /2)
#        #x = F.silu((output_model2 + output_model) /2)
#        #x = torch.mean(torch.stack((output_model2, output_model), dim=0), dim=0)

        
#        x = x.permute(0, 2, 1)
#        x = self.batch_norm(x)
#        x = x.permute(0, 2, 1)

#        return x










##class IntegratedModel(nn.Module):
##    def __init__(self, pred_len, seq_len, enc_in, batch_size2):
##        super(IntegratedModel, self).__init__()
##        self.pred_len = pred_len
##        self.seq_len = seq_len
##        self.channels = enc_in
##        self.batch_norm = nn.BatchNorm1d(self.channels)
        
##        # Common linear transformation layer
##        self.common_linear = nn.Linear(self.seq_len, self.pred_len)
##        #self.common_linear = nn.Linear(self.seq_len, 600)
##        #self.common_linear2 = nn.Linear(600, self.pred_len)
        
##        # Use ModuleList if individual linear layers per channel are required
##        self.individual_linear = nn.ModuleList([nn.Linear(self.seq_len, self.pred_len) for _ in range(self.channels)])
        
##        ## First set of individual linear layers (seq_len to 300)
##        #self.individual_linear1 = nn.ModuleList([nn.Linear(self.seq_len, 300) for _ in range(self.channels)])
##        ## Second set of individual linear layers (300 to pred_len)
##        #self.individual_linear2 = nn.ModuleList([nn.Linear(300, self.pred_len) for _ in range(self.channels)])

##        self.use_individual =False  # Set to True if individual linear transformations are needed

##    def forward(self, x):
##       # print(x.shape)
##        # Normalization step for Model2
##        seq_last = x[:, -1:, :].detach()
##        x_normalized = x - seq_last 
##        #x_normalized = x - seq_last

        
##        # Shared linear transformation
##        if self.use_individual:
##            output = torch.zeros([x.size(0), self.pred_len, x.size(2)], dtype=x.dtype).to(x.device)
##            for i in range(self.channels):
##                output[:, :, i] = self.individual_linear[i](x_normalized[:, :, i])
##                #channel_output = self.individual_linear1[i](x_normalized[:, :, i])
##                #output[:, :, i] = self.individual_linear2[i](channel_output)
##        else:
##            output = self.common_linear(x_normalized.permute(0, 2, 1)).permute(0, 2, 1)
          
            
##            #output = self.common_linear(x_normalized.permute(0, 2, 1))

##            #output =self.common_linear2(output).permute(0, 2, 1)
##        # Adding back the last time step
##        output += seq_last

##        # Original linear transformation from Model
##        if self.use_individual:
##            output_original = torch.zeros([x.size(0), self.pred_len, x.size(2)], dtype=x.dtype).to(x.device)
##            for i in range(self.channels):
##                #channel_output_original = self.individual_linear1[i](x[:, :, i])
##                #output_original[:, :, i] = self.individual_linear2[i](channel_output_original)
##                output_original[:, :, i] = self.individual_linear[i](x[:, :, i])
##        else:
##            output_original = self.common_linear(x.permute(0, 2, 1)).permute(0, 2, 1)
##            #output_original = self.common_linear(x.permute(0, 2, 1))
##            #output_original =self.common_linear2(output_original).permute(0, 2, 1)
##        # Averaging the outputs from the two transformations
        
##        #x = torch.sigmoid((output + output_original) / 2)
##        x = F.gelu((output + output_original) / 2)
##        #x =F.gelu( torch.mean(torch.stack((output, output_original), dim=0), dim=0))

##        #x = (output + output_original) / 2
##        # Apply batch normalization
##        x = x.permute(0, 2, 1)
##        x = self.batch_norm(x)
##        x = x.permute(0, 2, 1)
        
##        #x = torch.sigmoid(x)
##        #x = F.gelu(x)


##        #print(x.shape)
##        return x

















##class moving_avg(nn.Module):
##    """
##    Moving average block to highlight the trend of time series
##    """
##    def __init__(self, kernel_size, stride):
##        super(moving_avg, self).__init__()
##        self.kernel_size = kernel_size
##        self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=stride, padding=0)

##    def forward(self, x):
##        # padding on the both ends of time series
##        front = x[:, 0:1, :].repeat(1, (self.kernel_size - 1) // 2, 1)
##        end = x[:, -1:, :].repeat(1, (self.kernel_size - 1) // 2, 1)
##        x = torch.cat([front, x, end], dim=1)
##        x = self.avg(x.permute(0, 2, 1))
##        x = x.permute(0, 2, 1)
##        return x


##class series_decomp(nn.Module):
##    """
##    Series decomposition block
##    """
##    def __init__(self, kernel_size):
##        super(series_decomp, self).__init__()
##        self.moving_avg = moving_avg(kernel_size, stride=1)

##    def forward(self, x):
##        moving_mean = self.moving_avg(x)
##        res = x - moving_mean
##        return res, moving_mean
### Define the CombinedModel class



##class IntegratedModel(nn.Module):
##    def __init__(self, pred_len, seq_len, enc_in, batch_size2):
##        super(IntegratedModel, self).__init__()
##        self.seq_len = seq_len
##        self.pred_len = pred_len
##        self.channels = enc_in
        
##        # Decomposition part from Model2
##        kernel_size = 25
##        self.decomposition = series_decomp(kernel_size)

##        # Linear layers from Model2
##        self.Linear_Seasonal = nn.ModuleList([nn.Linear(seq_len, pred_len) for _ in range(enc_in)])
##        self.Linear_Trend = nn.ModuleList([nn.Linear(seq_len, pred_len) for _ in range(enc_in)])

##        # Batch normalization
##        self.batch_norm = nn.BatchNorm1d(self.channels)

##        # Additional linear layers from IntegratedModel
##        self.individual_linear = nn.ModuleList([nn.Linear(seq_len, pred_len) for _ in range(enc_in)])

##        # Flag to use individual linear transformations
##        self.use_individual = True 

##    def forward(self, x):
##        # Decomposition step
##        seasonal, trend = self.decomposition(x)
##        seasonal, trend = seasonal.permute(0, 2, 1), trend.permute(0, 2, 1)

##        # Apply linear transformations from Model2
##        seasonal_output = torch.zeros([x.size(0), self.channels, self.pred_len], dtype=x.dtype).to(x.device)
##        trend_output = torch.zeros([x.size(0), self.channels, self.pred_len], dtype=x.dtype).to(x.device)
##        for i in range(self.channels):
##            seasonal_output[:, i, :] = self.Linear_Seasonal[i](seasonal[:, i, :])
##            trend_output[:, i, :] = self.Linear_Trend[i](trend[:, i, :])

##        # Normalization and additional linear layers from IntegratedModel
##        x_normalized = x - x[:, -1:, :].detach() 
##        output = torch.zeros([x.size(0), self.pred_len, x.size(2)], dtype=x.dtype).to(x.device)
##        for i in range(self.channels):
##            output[:, :, i] = self.individual_linear[i](x_normalized[:, :, i])

##        # Combine outputs
##        output = output.permute(0, 2, 1)
##        #x_combined = (seasonal_output + trend_output + output) / 3
##        x_combined = (seasonal_output + trend_output ) / 2
##        #x_combined = torch.sigmoid(x_combined)

##        # Apply batch normalization
##        #x_combined = x_combined.permute(0, 2, 1)
##        x_combined = self.batch_norm(x_combined)
##        x_combined = x_combined.permute(0, 2, 1)

##        return x_combined









